
var container = document.getElementById("music-info");
var slider = document.getElementById("volumeSlider");
var np = document.getElementById("now-playing");
var playButton = document.getElementById("play-button")


if(config.enableMusic)
{
    InitControls();
    setInterval(UpdateMusicInfo, 1000);
}
else
{
    container.style.display = "none";
}


function InitControls()
{
    slider.setAttribute("value", config.musicVolume);
    slider.addEventListener("input", UpdateVolume, false);
}


function UpdateVolume()
{
    setVolume((slider.value-1));
}



function UpdateMusicInfo()
{

    if(title.length != 0)
    {
        np.innerHTML = "Teraz gra: " + title;
    }
    else
    {
        np.innerHTML = "Teraz gra: n.a.";
    }
}

var playing = true;



function OnPlayClick()
{
    if(playing)
    {
        playing = false;
        pause();

        playButton.classList.remove("icon-pause2")
        playButton.classList.add("icon-play3")
        
    }
    else
    {
        playing = true;
        resume();

        playButton.classList.remove("icon-play3")
        playButton.classList.add("icon-pause2")
    }
}

function OnSkipClick()
{
    if(playing)
    {
        skip();
    }
}



window.onload = function() 
{
  document.body.addEventListener("mousemove", function(event)
  {
        var cursor = document.getElementById("cursor");

        //TODO: More consistent way of aligning the cursor without awkward offsets?
        var x = event.pageX - cursor.width + 7;
        var y = event.pageY - 7;

        cursor.style.left = x;
        cursor.style.top = y;
  });
}